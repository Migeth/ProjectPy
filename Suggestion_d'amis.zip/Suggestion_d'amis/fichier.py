
def ouvrir_fichier(nom_fich):
    """
    Demande à l'utilisateur le fichier désiré et l'ouvre en mode 'lecture'

    """

    while True:
        try:
            fichier = open(nom_fich, 'r')
            break

        except FileNotFoundError:
            print("Verifier si le fichier est dans votre répertoire et n'oubliez pas d'ajoutez l'extension .txt")

    return fichier


def lire_fichier(fichier):
    """
    Utilise la fonction qui ouvre le fichier demandé par l'utilisateur et lit avant tout la première ligne du fichier
    où se trouve le nombre d'usager du réseau. Crée 'n' listes grâce à 'range'  de la variable 'n' qui enrégistre le
    nombre d'usager. Balaie chaque ligne du fichier qui contient un couple d'usagers amis et ajoute à la liste propre
    à un usager son ami.

    Args:
        fichier ouvert : 'fp'

    Returns:
        reseau d'amis (list)

    """

    reseau = []

    for i in range(n):
        reseau.append([])

    for line in fichier.readlines()[1:]:
        liste = list(line.split(' '))
        liste[-1] = liste[-1].rstrip('\n')
        elem1 = liste[0]
        elem2 = liste[1]
        if elem1 and elem2 in liste:
            reseau[int(elem1)].append(int(elem2))
            reseau[int(elem2)].append(int(elem1))

    return reseau


def trouver_nombre_elements_communs_entre_listes(liste1, liste2):
    """
    Trouve les éléments communs entre deux listes
    Args:
        les listes 1 et 2 (list) de la fonction qui calcule les scores de similarité

    Return:
        nombre d'éléments communs (int)

    """

    elem_commun = list(liste1 & liste2)
    nb_elem_commun = len(elem_commun)

    return nb_elem_commun


def initialiser_matrice(nombre):
    """
    Crée une matrice nxn, initialisée avec des zéros et retourne la matrice.
    Args:
        nombre (int): dimension de la matrice nxn
    Returns:
        matrice (list): matrice initialisée

    """
    matrice = []
    for ligne in range(nombre):  # pour chacune des lignes dans n
        matrice.append([])  # créer une ligne (liste) et l'initialiser à 0
        for colonne in range(nombre):
            matrice[ligne].append(0)  # ajouter un 0 pour chaque n colonne
    return matrice


def calculer_scores_similarite(reseau):
    """
    Prends la liste correspondant à un usager donné, cherche le nombre d'élements en commun qu'elle a avec la liste
    des autres usagers  et l'intègre à sa liste dans la matrice de similarité remplie par défaut de '0' fois le nombre
    d'usager
    Args:
        Le réseau (list) généré par la fonction qui lit le fichier

    Return:
        la matrice de similaritéé remplie (list)

    """

    matrice_similarite = initialiser_matrice(n)

    for i in range(n):
        for s in reseau:
            liste1 = set(reseau[i])
            liste2 = set(reseau[int(reseau.index(s))])
            nb_elem_commun = trouver_nombre_elements_communs_entre_listes(liste1, liste2)
            matrice_similarite[i][reseau.index(s)] = nb_elem_commun

    return matrice_similarite


def recommander(id_usager, reseau, matrice_similarite):
    """
    Prend en paramêtre l'id de l'usager souhaité, le reseau d'amis et la matrice de similarité du reseau pour
    recomander un ami à l'usager. L'algorithme cherche dans la liste de l'usager souhaité, l'usager qui a le plus
    d'amis en commun avec lui et vérifie si ce dernier n'ai pas dans sa liste d'ami. Si oui, il laisse cette suggestion
    qu'il remplace temporairement par zéro pour recommencé son analyse. Lorsqu'il trouvera l'usager ayant plus d'amis
    et qui n'est pas encore dans sa liste d'ami, il recommandera alors cet usager.

    Args:
         ID de l'usager souhaité (int), reseau d'amis (list) et la matrice de similarité (list)

    Returns:
        ID de l'usager (int) recommandé par l'algorithme

    """

    liste_score_sim = matrice_similarite[int(id_usager)]
    id_recommande = str

    val_max1 = max(liste_score_sim)
    post_val_max1 = liste_score_sim.index(val_max1)
    while id_recommande == str:
        for e in enumerate(liste_score_sim):
            if val_max1 == e[1] and id_usager == e[0]:
                liste_score_sim[int(post_val_max1)] = 0
                val_max1 = max(liste_score_sim)
                post_val_max1 = liste_score_sim.index(val_max1)
                new_matrice = matrice_similarite[int(id_usager)]
                liste_score_sim = new_matrice

            elif val_max1 == e[1] and id_usager != e[0]:
                if post_val_max1 == id_usager:
                    liste_score_sim[int(post_val_max1)] = 0
                    val_max1 = max(liste_score_sim)
                    post_val_max1 = liste_score_sim.index(val_max1)
                elif post_val_max1 != id_usager:
                    if post_val_max1 not in list(reseau[id_usager]):
                        id_recommande = e[0]
                        break
                    else:
                        liste_score_sim[int(post_val_max1)] = 0
                        val_max1 = max(liste_score_sim)
                        post_val_max1 = liste_score_sim.index(val_max1)
                        break

    return id_recommande


def main():

    fic = open(nom_fichier, 'r')
    reseau = lire_fichier(fic)
    matrice_similarite = calculer_scores_similarite(reseau)

    n_usager = len(reseau)

    while True:
        try:
            print()
            id_usager = int(input(
                    "Entrez l'id de l'usager pour lequel vous voulez une recommandation (entre 0 et {}): ".format(
                        n_usager - 1)))
            if id_usager not in range(n_usager):
                print("Erreur: l'usager doit est un nombre entier entre 0 et {} inclusivement".format(n_usager - 1))
            else:
                break

        except ValueError:
            print("Erreur: l'usager doit est un nombre entier entre 0 et {} inclusivement".format(n_usager - 1))

    id_recommande = recommander(id_usager, reseau, matrice_similarite)

    print("Pour la personne {}, nous vous recommandons l'ami {}.".format(id_usager, id_recommande))
    print()

    while True:
        continuer = 'OUI'
        arreter = 'NON'
        suggestion = input('Voulez-vous une autre recommandation (oui / non)?: ')
        suggestion = suggestion.upper()
        if suggestion == continuer:
            fp.close()
            main()
        elif suggestion == arreter:
            break

        break

    fp.close()


if __name__ == "__main__":
    print()
    nom_fichier = input("Nom du fichier contenant le reseau: ")
    fp = ouvrir_fichier(nom_fichier)
    nb = int(fp.readline())
    n = nb
    main()
