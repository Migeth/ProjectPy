
from tkinter import *
#appel à la classe Tk pour créer une instance (ou objet) fenetre
#fenetre est maintenant "initialisé"
"""
Essayez ce qui suit à l'endroit approprié:
fenetre.title('Et moi je dis:')
fenetre.geometry('300x300')
"""

fenetre = Tk()

 #p80; appel à la classe Label pour créer une étiquette
 #'fg' ou 'foreground'; il y a aussi bg pour background
 #essayez bg et changez la couleur
 # l’objet fenetre est le widget maître de l’objet phrase.
phrase = Label(fenetre, text='Bonjour tout le monde !', fg='red')
 #activons la méthode 'pack'.
 #Comme 'phrase' vient de la classe 'Label', ses méthodes nous sont accessibles
 # 'pack' apparaît dans plusieurs classes, elle ajoute l'élément créé dans la 'fenetre'
phrase.pack()


 #créons un autre widget esclave: un bouton; 'command' dit ce qui arrive quand on clique le bouton
 #ici on *dit* que la méthode 'destroy' associée à l'objet fenetre (de la classe Tk) devra être appelée
bouton = Button(fenetre, text='Quitter', command = fenetre.destroy)
bouton.pack()

 #ça y est, on démarre la fenêtre. Une méthode de l'objet fenetre (de la classe Tk)
 #il s'agit d'une boucle qui tourne en toile de fond pour détecter les événements.
fenetre.mainloop()
