from tkinter import Tk, Radiobutton, IntVar


class MaFenetre:
    def __init__(self):
        self.root = Tk()
        self.x = IntVar()

        b_1 = Radiobutton(self.root, text="bouton1", variable=self.x, value=1, command=self.imprimer_x)
        b_2 = Radiobutton(self.root, text="bouton2", variable=self.x, value=2, command=self.imprimer_x)
        b_3 = Radiobutton(self.root, text="bouton3", variable=self.x, value=3, command=self.imprimer_x)

        b_1.grid(row=0, column=0)
        b_2.grid(row=0, column=1)
        b_3.grid(row=0, column=2)

        self.x.set(2)
        self.root.mainloop()

    def imprimer_x(self):
        print(self.x.get())


if __name__ == '__main__':
    fenetre = MaFenetre()