from tkinter import Tk, StringVar, ttk


class MaFenetre:
    def __init__(self):
        self.root = Tk()
        self.valeur = StringVar()

        self.box = ttk.Combobox(self.root, textvariable=self.valeur, state="readonly")
        self.box["values"] = ["A", "B", "C"]
        self.box.current(0)
        self.box.grid()
        self.box.bind("<<ComboboxSelected>>", self.imprimer_valeur)

        self.root.mainloop()

    def imprimer_valeur(self, event):
        print(self.valeur.get())


if __name__ == '__main__':
    fenetre = MaFenetre()