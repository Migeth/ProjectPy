from tkinter import Tk, Entry, Canvas, Label


class ExempleBind:
    def __init__(self):

        fenetre = Tk()
        self.entree = Entry()
        self.entree.grid()

        self.canvas = Canvas(fenetre, bg="light grey", height=500, width=500)
        self.canvas.grid(padx=5, pady=5)

        fenetre.bind("<Button-1>", self.pointer)
        fenetre.bind("<Button-3>", self.ecrire)
        fenetre.bind("<B1-Motion>", self.dessiner)

        self.chaine = Label(fenetre)
        self.chaine.grid()

        fenetre.mainloop()

    def pointer(self, event):
        self.chaine["text"] = "Clic détecté en x={}, y={}".format(event.x, event.y)

    def dessiner(self, event):
        self.canvas.create_oval(event.x - 2, event.y - 2, event.x + 2, event.y + 2, fill="black")

    def ecrire(self, event):
        self.canvas.create_text(event.x, event.y, text=self.entree.get(), fill="black")


if __name__ == '__main__':
    exemple = ExempleBind()