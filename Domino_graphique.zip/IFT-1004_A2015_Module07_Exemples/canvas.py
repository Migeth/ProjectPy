from tkinter import Tk, Frame, Canvas, N, S

# coordonnées initiales
x_1, y_1 = 50, 75

#coordonées finales
x_2, y_2 = 200, 225

# Création du widget principal ("parent") :
fen1 = Tk()
fen1.title("Exemple de Canvas")

# création des widgets "enfants" :
f1 = Frame(fen1)
f1.grid()
can1 = Canvas(f1,bg='dark grey', height=250, width=250)
can1.grid(padx=5, pady=5)

# Dessin
can1.create_rectangle(x_1, y_1, x_2, y_2, width=1, fill='blue')
can1.create_oval(x_1, y_1, x_2, y_2, width=2, fill='red')
can1.create_polygon(x_1, y_1, x_2, y_1, (x_1 + x_2) // 2, y_1 // 2, width=3, fill='green')
can1.create_line(x_1, y_1, x_2, y_2, width=4, fill='yellow')
can1.create_text(x_1, y_1, text="({}, {})".format(x_1, y_1), anchor=S, fill='black', font=("Helvetica", "11"))
can1.create_text(x_2, y_2, text="({}, {})".format(x_2, y_2), anchor=N, fill='black', font=("Helvetica", "11"))

# démarrage du réceptionnaire d'évènements (boucle principale) :
fen1.mainloop()
