"""
Module contenant la description de la classe Partie. Cette classe contient toutes les méthodes pour jouer une partie de
domino sans pioche.
"""

import pydomino
import random


def distribuer_dominos(nombre_joueurs):
    """
    Méthode pour créer les donnes des joueurs. Pour une partie à 2 joueurs, 7 dominos sont distribués aux joueurs. Pour
    une partie à 3 ou 4 joueurs, 6 dominos sont distribués aux joueurs. Pour cette fonction, nous vous suggérons de
    générer tous les dominos de l'ensemble 'double-six', ensuite de les brasser aléatoirement (voir la fonction shuffle
    du module random), et de retourner le nombre de donnes demandé.
    :param nombre_joueurs: (int) Nombre de joueurs de la partie.
    :return: (list) La liste des donnes de dominos des joueurs.
    """
    Tous_les_dominos = []
    nb_de_domino = 0
    donne = []

    for i in range(7):
        for r in range(i + 1):
            domino = pydomino.Domino(r, i)
            Tous_les_dominos.append(domino)

    random.shuffle(Tous_les_dominos)

    if nombre_joueurs == 2:
        nb_de_domino = 7

    if nombre_joueurs == 3 or nombre_joueurs == 4:
        nb_de_domino = 6

    for n in range(nombre_joueurs):
        echantillons = random.sample(Tous_les_dominos, nb_de_domino)
        donne_1 = pydomino.Donne(echantillons)
        donne.append(donne_1)
        for p in echantillons:
            Tous_les_dominos.remove(p)

    return donne


class Partie:
    """
    Documentation de la classe Partie
    Attributs:
        plateau (Plateau): Objet qui contiendra les dominos qui seront joués par les joueurs
        donnes (list): Liste des donnes des joueurs. Les donnes sont des objets de la classe Donne
        tour (int): Nombre qui représente le joueur dont c'est le tour de jouer
        passe (int): Nombre de joueurs consécutifs qui passent leur tour.
        gagnant (int): Nombre qui représente le joueur gagnant lorsqu'on joueur gagne la partie
    """

    def __init__(self, plateau, donnes):
        self.plateau = plateau
        self.donnes = donnes
        self.tour = None
        self.passe = 0
        self.gagnant = None

    @classmethod
    def nouvelle_partie(cls, nombre_joueurs):
        """
        Méthode de classe pour créer une nouvelle partie. Cette méthode instancie le plateau de jeu, crée les donnes
        des joueurs (selon le nombre de joueurs reçu en argument) et instancie l'objet partie.
        :param nombre_joueurs: (int) nombre de joueurs de la partie
        :return: (Partie) objet de la classe Partie
        """

        plateau = pydomino.Plateau()

        donnes = distribuer_dominos(nombre_joueurs)

        partie = Partie(plateau, donnes)

        return partie

    @staticmethod
    def afficher_instructions():
        """
        Méthode statique qui affiche les instructions du jeu

        """
        print("""
        ================================= Domino ===================================
        -------Bienvenue dans la partie "Sans Pioche" de notre jeu de domino.-------
        --------------Ce jeu peut-être joué par 2, 3 ou 4 joueurs.------------------
        
        Voici les instructions du jeu:
        
        1) Le premier joueur à déposer un domino est celui qui a le domino le plus
         élevé (les trois dominos les plus élevés sont [6,6], [5,6] et [5,5]).
         
        2) Il doit nécessairement déposer ce domino en premier.
        
        3) Chaque joueur joue ensuite à tour de rôle.
        
        4) Pour déposer un domino, un joueur doit choisir un domino de sa donne qui
        a un numéro identique à une des extrémités de la suite de dominos qui 
        s’assemble sur la table.
        
        5) Si un joueur ne peut jouer aucun domino, il doit passer son tour.
        
        -----------------La partie se termine dans deux conditions :---------------
        ||| Si un joueur a déposé tous ses dominos et a vidé sa donne. Ce joueur 
        est déclaré gagnant.
        
        ||| Si aucun joueur ne peut déposer un domino (ils auront donc tous passé 
        leur tour), la partie est arrêtée. Le joueur à qui il reste le moins de 
        dominos dans sa donne est déclaré gagnant. En comptant le nombre de dominos 
        restants, il se peut qu’il y ait égalité entre 2 joueurs ou plus.
                
        ============================ Amusez vous !! ===============================
        """)

    def afficher_etat_donnes(self):
        """
        Méthode qui affiche l'état des donnes des joueurs de la partie.
        L'information affichée doit contenir le numéro du joueur et le nombre de domino de sa donne.
        """

        for a, b in enumerate(self.donnes):
            print("Le Joueur {} dispose actuellement de {} domino(s).".format(a, len(b)))

    def trouver_premier_joueur(self):
        """
        Méthode qui détermine le premier joueur à déposer un domino sur le plateau. Ce joueur est celui qui a le domino
        le plus élevé ([6,6], [5,6], [5,5], ou moins).
        :return:
            int: le numéro du joueur ayant le domino le plus élevé
            domino: le domino le plus élevé de ce joueur
        """

        liste_arrangee = []
        prem_liste = []

        for i in self.donnes:
            arr = sorted(i, reverse=True)
            liste_arrangee.append(arr)

        for j in liste_arrangee:
            prem_liste.append(j[0])

        liste = sorted(prem_liste, reverse=True)
        domino = liste[0]
        num_joueur = int

        for e in self.donnes:
            if domino in e:
                num_joueur = int(self.donnes.index(e))

        return num_joueur, domino

    def passer_au_prochain_joueur(self):
        """
        Méthode qui modifie l'attribut self.tour pour passer au joueur suivant.
        """
        last_player = self.donnes[-1]
        if self.tour == self.donnes.index(last_player):
            self.tour = 0
        else:
            self.tour = self.tour + 1

    def tour_du_premier_joueur(self):
        """
        Méthode qui complète les étapes du tour du premier joueur.
        """

        info = Partie.trouver_premier_joueur(self)
        print("C'est le joueur {} qui joue en premier car il dispose du plus grand domino ({})".format(
                                                                                                    info[0], info[1]))
        self.plateau.ajouter(info[1], False)
        self.tour = info[0]
        pydomino.Donne.jouer(self.donnes[self.tour], info[1])
        Partie.passer_au_prochain_joueur(self)
        affiche = " Plateau "
        print(affiche.center(160, "-"))
        plat = self.plateau.plateau
        dom = ""
        for i in plat:
            dom += str(i)
        print(dom.center(160, " "))
        print("-" * 160)
        print()

    def determiner_si_domino_peut_etre_joue(self, domino):
        """
        Méthode qui détermine si un domino peut être joué sur le plateau de jeu.
        :param domino: (Domino) Domino dont on veut savoir s'il peut être posé à une des deux extrémités du plateau
        :return: (bool) True, si le domino peut être joué, False autrement.
        """

        if pydomino.Domino.__contains__(domino, pydomino.Plateau.cote_droit(self.plateau)) is True or \
                pydomino.Domino.__contains__(domino, pydomino.Plateau.cote_gauche(self.plateau)) is True:
            statut = True
        else:
            statut = False

        return statut

    def determiner_si_joueur_joue_ou_passe(self):
        """
        Méthode qui détermine si le joueur courant peut jouer un domino ou s'il doit passer son tour.
        :return: (bool) True, si au moins un domino de la donne du joueur courant peut être joué sur le plateau. False,
        autrement.
        """

        statut = bool

        for element in self.donnes[self.tour]:
            if Partie.determiner_si_domino_peut_etre_joue(self, element):
                statut = True
                break
            else:
                statut = False

        return statut

    def afficher_informations_debut_tour(self):
        """
        Méthode qui affiche les informations données à chaque début de tour: le numéro du joueur qui doit jouer, l'état
        du plateau de jeu, l'état des donnes de tous les joueurs (nombre de dominos en main) et la donne du joueur qui
        doit jouer.
        """

        print()
        print("C'est au tour du joueur", self.tour, "de jouer")
        print()
        affiche = " Plateau "
        print(affiche.center(160, "-"))
        plat = self.plateau.plateau
        dom = ""
        for i in plat:
            dom += str(i)
        print(dom.center(160, " "))
        print("-" * 160)
        print()
        self.afficher_etat_donnes()
        print()
        print("Voici actuellement votre donne: ")
        for a, b in enumerate(self.donnes[self.tour]):
            print("{} : {}".format(a, b))

    def demander_numero_domino_a_jouer(self):
        """
        Méthode qui demande le numéro du domino que le joueur veut jouer. En posant la question, le programme affiche la
        liste des dominos dans la donne du joueur. Le numéro est validé et le programme redemande un numéro de domino
        tant que le numéro fourni n'est pas valide.
        :return: (Domino) L'objet domino associé au numéro de domino choisi.
        """

        while True:
            try:
                print()
                numero_domino = int(input("Veillez saisir le numéro du domino que vous voulez jouer {} : ".format(
                    self.donnes[self.tour]
                )))
                if numero_domino not in range(len(self.donnes[self.tour])):
                    print("Vérifier que vous avez entré un numéro compris entre 0 et {}!".
                          format(len(self.donnes[self.tour]) - 1))

                else:
                    domino = self.donnes[self.tour][numero_domino]
                    if Partie.determiner_si_domino_peut_etre_joue(self, domino) is True:
                        return domino

                    else:
                        print("Vous pouvez pas jouer ce domino.")

            except ValueError:
                print("Attention!!  Vérifiez votre réponse et entrez le numéro du domino à jouer entre 0 et {})!".
                      format(len(self.donnes[self.tour]) - 1))

    def jouer_a_gauche_ou_a_droite(self, domino_joue):
        """
        Méthode qui est invoquée lorsque le domino choisi par le joueur peut être joué à gauche ou à droite. On demande
        ce que veut le joueur et le domino est joué selon son choix. Ce choix doit être validé par le programme.
        :param domino_joue: (Domino) Le domino à jouer
        :return:
        """
        choix = input("Votre domino peut être joué à doite comme à gauche, où voulez vous le jouer? (g/d): ").lower()
        if choix == "g":
            Partie.jouer_a_gauche(self, domino_joue)

        elif choix == "d":
            Partie.jouer_a_droite(self, domino_joue)

        else:
            Partie.jouer_a_gauche_ou_a_droite(self, domino_joue)

        return

    def jouer_a_gauche(self, domino_joue):
        """
        Méthode invoquée pour joueur un domino à gauche du plateau.
        :param domino_joue: (Domino) Le domino à jouer à gauche du plateau.
        """
        plat = pydomino.Plateau
        print("Votre domino {} est placé à gauche.".format(domino_joue))
        plat.ajouter_a_gauche(self.plateau, domino_joue)
        affiche = " Plateau "
        print(affiche.center(160, "-"))
        plat = self.plateau.plateau
        dom = ""
        for i in plat:
            dom += str(i)
        print(dom.center(160, " "))
        print("-" * 160)
        pydomino.Donne.jouer(self.donnes[self.tour], domino_joue)

    def jouer_a_droite(self, domino_joue):
        """
        Méthode invoquée pour joueur un domino à droite du plateau.
        :param domino_joue: (Domino) Le domino à jouer à droite du plateau.
        """
        plat = pydomino.Plateau
        print("Votre domino {} est placé à droite.".format(domino_joue))
        plat.ajouter_a_droite(self.plateau, domino_joue)
        affiche = " Plateau "
        print(affiche.center(160, "-"))
        plat = self.plateau.plateau
        dom = ""
        for i in plat:
            dom += str(i)
        print(dom.center(160, " "))
        print("-" * 160)
        pydomino.Donne.jouer(self.donnes[self.tour], domino_joue)

    def jouer_un_domino(self):
        """
        Méthode pour jouer un domino. Cette méthode demande au joueur le numéro du domino qu'il souhaite jouer. Elle
        vérifie ensuite si le domino peut être joué à gauche ou à droite du plateau. Si le domino peut être joué d'un
        seul côté, alors le domino est joué de ce côté-là. Si le domino peut être joué des deux côtés, alors on
        demande à l'utilateur le côté où il souhaite jouer le domino (en utilisant les méthodes appropriées).
        """
        domino_joueur = Partie.demander_numero_domino_a_jouer(self)
        p = pydomino.Plateau
        d = pydomino.Domino

        if d.__contains__(domino_joueur, p.cote_gauche(self.plateau)) and \
                d.__contains__(domino_joueur, p.cote_droit(self.plateau)) is True:
            Partie.jouer_a_gauche_ou_a_droite(self, domino_joueur)

        elif d.__contains__(domino_joueur, p.cote_gauche(self.plateau)) is True and \
                d.__contains__(domino_joueur, p.cote_droit(self.plateau)) is False:
            Partie.jouer_a_gauche(self, domino_joueur)

        elif d.__contains__(domino_joueur, p.cote_droit(self.plateau)) is True and \
                d.__contains__(domino_joueur, p.cote_gauche(self.plateau)) is False:
            Partie.jouer_a_droite(self, domino_joueur)

    def tour_du_prochain_joueur(self):
        """
        Méthode qui exécute les étapes de jeu pour le tour d'un joueur (à l'exception du premier tour qui a une
        méthode dédiée). Dans cette méthode: 1) on affiche les informations de début de tour, ensuite 2) on teste si
        le joueur courant peut jouer ou s'il doit passer son tour, 3) s'il peut jouer, on réinitialise l'attribut passe,
        le joueur joue un domino, et on vérifie s'il y a un gagnant, 4) s'il ne peut pas joueur, on fait passer son tour
        au joueur, finalement 4) on passe au prochain joueur (en utilisant la méthode appropriée).
        """

        Partie.afficher_informations_debut_tour(self)
        determination = Partie.determiner_si_joueur_joue_ou_passe(self)
        if determination is True:
            self.passe = 0
            Partie.jouer_un_domino(self)
            Partie.verifier_gagnant(self)
            if self.gagnant is None:
                Partie.passer_au_prochain_joueur(self)
        else:
            self.faire_passer_joueur()

    def faire_passer_joueur(self):
        """
        Méthode qui contient les instructions à exécuter lorsqu'un joueur doit passer son tour. Cette méthode devrait
        afficher des informations et modifier l'attribut passe.
        """

        print("Le joueur {} ne peut pas jouer et passe son tour.".format(self.tour))
        Partie.passer_au_prochain_joueur(self)
        self.passe += 1
        if self.passe == len(self.donnes):
            return
        else:
            Partie.tour_du_prochain_joueur(self)

    def verifier_gagnant(self):
        """
        Méthode qui vérifie si le joueur courant est le gagnant (condition: il doit avoir vidé sa donne). Cette méthode
        modifie l'attibut gagnant si le joueur courant gagne la partie.
        """
        if len(self.donnes[self.tour]) == 0:
            self.gagnant = self.tour

    def trouver_joueurs_avec_moins_de_dominos(self):
        """
        Méthode qui détermine le ou les joueurs qui ont la plus petite donne.
        :return: (list) Liste contenant les numéros des joueurs ayant le moins de dominos dans leur donne. Ce nombre
        peut varier entre 1 et len(self.donnes)
        """
        less_domino_player = []
        nb_domino = []
        for i in self.donnes:
            if len(i) != 0:
                nb_domino.append(len(i))
        for a, b in enumerate(self.donnes):
            if len(b) == min(nb_domino):
                less_domino_player.append(a)

        return less_domino_player

    def afficher_message_egalite(self, indices):
        """
        Méthode qui affiche un message en cas d'égalité en fin de partie. Ce message doit indiquer quels sont
        les joueurs qui ont le moins de dominos dans leur donne.
        :param indices: (list) Liste qui contient les numéros des joueurs ayant le moins de dominos dans leur donne.
        """
        g = str(indices)
        h = "{}".format(g.rstrip("]"))
        joueur = "{}".format(h.lstrip("["))
        print()
        print("Les joueurs {} possèdent moins de domino, ils sont donc à égalité.".format(joueur))
        self.gagnant = joueur
        print()
        print("Merci d'avoir jouer à cette partie. A la prochaine !!")

    def afficher_message_victoire(self):
        """
        Méthode qui affiche le message de victoire. Il informe l'usager de l'identité du joueur gagnant.
        """
        print()
        print("Victoire !!! Le joueur {} a gagné. Toutes mes félicitations!".format(self.gagnant))

    def jouer(self):
        """
        Méthode principale de la classe qui spécifie le déroulement d'une partie. Les étapes sont: 1) affichage des
        instructions, 2) premier tour de jeu, 3) boucle pour les tours suivants, cette boucle vérifie les conditions de
        fin de partie, 4) affichages de fin de partie (état des donnes, message en cas de victoire ou d'égalité)
        """

        self.afficher_instructions()
        self.tour_du_premier_joueur()
        while self.gagnant is None:
            self.tour_du_prochain_joueur()
            if self.passe == len(self.donnes):
                self.afficher_etat_donnes()
                joueur_AMD = Partie.trouver_joueurs_avec_moins_de_dominos(self)
                if len(joueur_AMD) > 1:
                    Partie.afficher_message_egalite(self, joueur_AMD)
                    break

                elif len(joueur_AMD) == 1:
                    self.gagnant = joueur_AMD[0]
                    Partie.afficher_message_victoire(self)
                    break

        else:
            Partie.afficher_message_victoire(self)
