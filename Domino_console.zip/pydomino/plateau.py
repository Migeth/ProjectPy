import pydomino


class Plateau:
    """
        Documentation de la classe Plateau
        Attributs:
            plateau (list): Liste de dominos contenant les dominos qui ont été joués.
        """

    def __init__(self):
        self.plateau = list()

    def cote_gauche(self):
        """
        Méthode qui retourne la valeur numérique à gauche du plateau
        :return: La valeur extérieure du domino de gauche.
        """

        if len(self.plateau) == 1:
            valeur = self.plateau[0].premier_chiffre

        else:
            valeur = self.plateau[0].premier_chiffre

        return int(valeur)

    def cote_droit(self):
        """
        Méthode qui retourne la valeur numérique à droite du plateau
        :return: La valeur extérieure du domino de droite.
        """

        if len(self.plateau) == 1:
            valeur = self.plateau[0].deuxieme_chiffre

        else:
            valeur = self.plateau[-1].deuxieme_chiffre

        return int(valeur)

    def ajouter_a_gauche(self, domino):
        """
        Méthode qui ajoute le domino reçu en argument à gauche du plateau. Le domino devra peut-être être inversé pour
        que les chiffres qui se touchent soient identiques.
        :param domino: (Domino) Le domino à ajouter à gauche.
        """

        if domino.premier_chiffre == Plateau.cote_gauche(self):
            domino_joue = pydomino.Domino.inverser(domino)
            self.plateau[:0] = [domino_joue]
        elif domino.deuxieme_chiffre == Plateau.cote_gauche(self):
            self.plateau[:0] = [domino]

    def ajouter_a_droite(self, domino):
        """
        Méthode qui ajoute le domino reçu en argument à gauche du plateau. Le domino devra peut-être être inversé pour
        que les chiffres qui se touchent soient identiques.
        :param domino: (Domino) Le domino à ajouter à droite.
        """

        if domino.premier_chiffre == Plateau.cote_droit(self):
            self.plateau.append(domino)
        elif domino.deuxieme_chiffre == Plateau.cote_droit(self):
            domino_joue = pydomino.Domino.inverser(domino)
            self.plateau.append(domino_joue)

    def ajouter(self, domino, gauche):
        """
        Méthode qui ajoute le domino reçu en argument à gauche ou à droite du plateau.
        :param domino: (Domino) Le domino à ajouter à droite.
        :param gauche: (bool) True si le domino doit être ajouté gauche, False autrement
        """

        if len(self.plateau) == 0:
            self.plateau = [domino]

        else:
            if gauche is True:
                Plateau.ajouter_a_gauche(self, domino)

            else:
                Plateau.ajouter_a_droite(self, domino)

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        return not self == other

    def __len__(self):
        return len(self.plateau)

    @property
    def __str__(self):
        """
        Méthode qui retourne une chaîne de caractères qui représente la liste de dominos sur le plateay en une ligne.
        :return: str: liste des dominos du plateau
        """

        return str(self.plateau)

    def __repr__(self):

        return str(self)
