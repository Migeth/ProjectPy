"""
Module principal du package pydomino. C'est ce module que nous allons exécuter pour démarrer votre jeu.
"""

import pydomino.partie
from pydomino.partie_avec_pioche import PartieAvecPioche


if __name__ == '__main__':
    """
    Point d'entrée de votre programme pydomino. Dans cette fonction, il faut d'abord demander quel type de partie de
    dominos l'utilisateur veut jouer. L'entrée de l'utilisateur doit être validée. Ensuite, le programme demande à
    l'utilisateur à combien de joueur il veut jouer une partie. Un objet de la classe Partie ou de la classe 
    PartieAvecPioche est ensuite instancié. Finalement, la partie est démarrée en appelant la méthode jouer().
    """
    print("Jouons une partie de pydomino!\n")
    while True:
        try:
            choix_jeu = int(input("""               
                                      BIENVENUE

Bienvenue dans notre jeu de domino. Vous pouvez jouer à n'importe quel partie que vous voulez
             
      1) Sans Pioche
      2) Avec Pioche
             
A quelle partie voulez-vous jouer? (1 ou 2)? : """))

            while True:
                try:
                    nombre_joueur = int(input("Entrez le nombre de joueur qui joueront à la partie: "))
                    if nombre_joueur in range(2, 5):
                        break

                    else:
                        print("Entrez un nombre entre 2, 3 et 4")

                except ValueError:
                    print("Entrez un nombre entre 2, 3 et 4")

            if choix_jeu == 1:
                partie = pydomino.Partie.nouvelle_partie(nombre_joueur)
                pydomino.Partie.jouer(partie)
                break

            elif choix_jeu == 2:
                partie_sans = PartieAvecPioche.nouvelle_partie(nombre_joueur)
                pydomino.PartieAvecPioche.jouer(partie_sans)
                break

            else:
                print("Choix impossible!! Tapez un chiffre entre 1 et 2")

        except ValueError:
            print("Choix impossible!! Tapez un chiffre entre 1 et 2")

print()
input('Appuyer sur ENTER pour quitter.')
