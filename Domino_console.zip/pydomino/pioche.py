import pydomino
from random import randint


class Pioche(pydomino.Donne):
    """
    Documentation de la classe Pioche. Cette classe hérite de la classe Donne
    Attributs:
        Aucun attribut spécifique autre que ceux de la classe Donne.
    """

    def prendre_dans_la_pioche(self):
        """
        Méthode pour prendre un domino dans la pioche.
        :return:
            (domino): le domino pris dans la pioche
        """

        index_dom = randint(0, (len(self) - 1))
        dom = self[index_dom]
        pydomino.Donne.jouer(self, dom)

        return dom
