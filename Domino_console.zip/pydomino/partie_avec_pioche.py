import pydomino
import random


def distribuer_dominos_avec_pioche(nombre_joueurs):
    """
        Méthode pour créer les donnes des joueurs et la pioche. Pour une partie à 2 joueurs, 7 dominos sont distribués
        aux joueurs. Pour une partie à 3 ou 4 joueurs, 6 dominos sont distribués aux joueurs. Pour cette fonction, nous
        vous suggérons de générer tous les dominos de l'ensemble 'double-six', ensuite de les brasser aléatoirement
        (voir la fonction shuffle du module random), et de retourner le nombre de donnes demandé. Dans tous les cas,
        les jetons restants forment la pioche.
        :param nombre_joueurs: (int) Nombre de joueurs de la partie.
        :returns: (list) La liste des donnes de dominos des joueurs.
                (Pioche) L'objet pioche.
        """
    pioche = []
    nb_de_domino = 0
    donne = []

    for i in range(7):
        for r in range(i + 1):
            domino = pydomino.Domino(r, i)
            pioche.append(domino)

    random.shuffle(pioche)

    if nombre_joueurs == 2:
        nb_de_domino = 7

    if nombre_joueurs == 3 or nombre_joueurs == 4:
        nb_de_domino = 6

    for n in range(nombre_joueurs):
        echantillons = random.sample(pioche, nb_de_domino)
        donne_1 = pydomino.Donne(echantillons)
        donne.append(donne_1)
        for p in echantillons:
            pioche.remove(p)

    return donne, pioche


class PartieAvecPioche(pydomino.Partie):
    """
        Documentation de la classe PartieAvecPioche. Cette classe hérite de la classe Partie.
        Attributs:
            pioche (Pioche): Pioche contenant une liste de dominos.
        """

    def __init__(self, plateau, donnes, pioche):

        self.pioche = pioche
        super().__init__(plateau, donnes)

    @classmethod
    def nouvelle_partie(cls, nombre_joueurs):
        """
        Méthode de classe pour créer une nouvelle partie avec pioche. Cette méthode instancie le plateau de jeu, crée
        les donnes des joueurs (selon le nombre de joueurs reçu en argument), la pioche et instancie l'objet partie.
        :param nombre_joueurs: (int) nombre de joueurs de la partie
        :return: (Partie) objet de la classe Partie
        """
        plateau = pydomino.Plateau()

        donnes, pioche = distribuer_dominos_avec_pioche(nombre_joueurs)

        partie = cls(plateau, donnes, pioche)

        return partie

    @staticmethod
    def afficher_instructions():
        """
        Méthode statique qui affiche les instructions du jeu

        """
        print("""
                ================================= Domino ===================================
                -------Bienvenue dans la partie "Avec Pioche" de notre jeu de domino.-------
                --------------Ce jeu peut-être joué par 2, 3 ou 4 joueurs.------------------

                Voici les instructions du jeu:

                1) Le premier joueur à déposer un domino est celui qui a le domino le plus
                 élevé (les trois dominos les plus élevés sont [6,6], [5,6] et [5,5]).

                2) Il doit nécessairement déposer ce domino en premier.

                3) Chaque joueur joue ensuite à tour de rôle.

                4) Pour déposer un domino, un joueur doit choisir un domino de sa donne qui
                a un numéro identique à une des extrémités de la suite de dominos qui 
                s’assemble sur la table.

                5) Si un joueur ne peut jouer aucun domino de sa donne, il doit piger un 
                domino dans la pioche jusqu'à ce qu'il ait un domino lui permettant de jouer.
                
                6) Si un joueur ne dispose pas d'un domino qui peut lui permettre de jouer et
                que la pioche est vide, alors il passe son tour. 

                -----------------La partie se termine dans deux conditions :---------------
                ||| Si un joueur a déposé tous ses dominos et a vidé sa donne. Ce joueur 
                est déclaré gagnant.

                ||| Si aucun joueur ne peut déposer un domino (ils auront donc tous passé 
                leur tour), la partie est arrêtée. Le joueur à qui il reste le moins de 
                dominos dans sa donne est déclaré gagnant. En cherchant celui qui dispose 
                du plus petit nombre de dominos restants, il se peut qu’il y ait égalité 
                entre 2 joueurs ou plus.

                ============================ Amusez vous !! ===============================
                """)

    def afficher_etat_donnes(self):
        """
        Méthode qui affiche l'état des donnes des joueurs de la partie avec pioche.
        L'information affichée doit contenir le numéro du joueur et le nombre de dominos de sa donne, ainsi que le
        nombre de dominos dans la pioche.
        """

        for a in self.donnes:
            index_dom = self.donnes.index(a)
            print("Le Joueur {} dispose actuellement de {} domino(s).".format(index_dom, len(a)))

        print("La pioche contient actuellement {} dominos.".format(len(self.pioche)))

    def faire_passer_joueur(self):
        """
        Méthode qui contient les instructions à exécuter lorsqu'un joueur doit passer son tour. Cette méthode devrait
        d'abord afficher des informations. Ensuite le joueur courant pige un domino dans la pioche. S'il peut jouer le
         domino, il le joue et son tour ce termine. S'il ne peut pas jouer, il pige un autre domino. Le joueur pigera
         des dominos tant qu'il ne pourra pas jouer le domino. Si jamais la pioche est vide, le programme affiche un
         message d'information et le joueur passe son tour.
        """

        print("Vous n'avez actuellement aucun domino dans votre donne qui peut jouer.")

        if len(self.pioche) != 0:
            pioche = pydomino.Pioche(self.pioche)
            domino_choisi = pioche.prendre_dans_la_pioche()
            pydomino.Donne.piger(self.donnes[self.tour], domino_choisi)
            self.pioche.remove(domino_choisi)
            check = pydomino.Partie.determiner_si_domino_peut_etre_joue(self, domino_choisi)
            if check is True:
                print()
                print("Voici actuellement les dominos de votre donne:")
                for i, o in enumerate(self.donnes[self.tour]):
                    print("{} : {}".format(i, o))
                pydomino.Partie.jouer_un_domino(self)
                pydomino.Partie.passer_au_prochain_joueur(self)
                pydomino.Partie.tour_du_prochain_joueur(self)

        else:
            print("Il ne reste malheureusement plus de domino dans la pioche.")
            pydomino.Partie.passer_au_prochain_joueur(self)
            self.passe += 1
